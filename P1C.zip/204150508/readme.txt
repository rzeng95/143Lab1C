Distribution of work:

Roland: Frontend development and selenium testing.
Siyu: Backend development

Grace Days used: 2
